
package net.mcreator.forgegodenapple.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.forgegodenapple.init.ForgegodenappleModItems;

public class GodenpickaxeItem extends PickaxeItem {
	public GodenpickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 10000;
			}

			public float getSpeed() {
				return 30f;
			}

			public float getAttackDamageBonus() {
				return 8f;
			}

			public int getLevel() {
				return 4;
			}

			public int getEnchantmentValue() {
				return 30;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(ForgegodenappleModItems.GODENINGOT.get()));
			}
		}, 1, -3f, new Item.Properties().fireResistant());
	}
}
