
package net.mcreator.forgegodenapple.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GodeningotItem extends Item {
	public GodeningotItem() {
		super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
	}
}
